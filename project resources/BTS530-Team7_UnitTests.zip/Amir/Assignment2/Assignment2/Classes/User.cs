﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment2.Classes
{
    public class User
    {
        int userID;
        string firstName;
        string lastName;
        int phone;
        string address;
        string email;
        string password;
        string status;

        public User(int uID, string fName, string lName, int p, string add, string e, string pass, string s)
        {
            this.userID = uID;
            this.firstName = fName;
            this.lastName = lName;
            this.phone = p;
            this.address = add;
            this.email = e;
            this.password = pass;
            this.status = s;

        }
        public string getUserName()
        {
            return this.firstName + ", " + this.lastName;
        }
    }
}