﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment2.Classes
{
    public class MachineBrand
    {
        int brandID;
        string brandName;
        int brandSerialNumber;


        public MachineBrand(int bID, string bName, int mBrandNumber)
        {
            this.brandID = bID;
            this.brandName = bName;
            this.brandSerialNumber = mBrandNumber;


        }
        public int getMachineBrandID()
        {
            return this.brandID;
        }
        public int getMachineSerialNumber(int bID)
        {
            if (bID == this.brandID)
                return this.brandSerialNumber;
            else
                return 0;
        }
        public string getMachineBrandName(int bID)
        {
            if (bID == this.brandID)
                return this.brandName;
            else
                return null;
        }
    }
}