﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment2.Classes
{
    public class Machine
    {
        int mNumber;
        string mName;
        double coverSquireFeet;
        int serialNumber;
        string status;
        double machineCost;
        MachineBrand machineBrand;
        User user;

        public Machine(int Num, string Name, double CSFeet, int serialNum, string s, MachineBrand m, User u, double mCost)
        {
            this.mNumber = Num;
            this.mName = Name;
            this.coverSquireFeet = CSFeet;
            this.serialNumber = serialNum;
            this.status = s;
            this.machineCost = mCost;
            this.machineBrand = m;
            this.user = u;

        }
        public string getMachineName(int mnum)
        {
            if (mnum == this.mNumber)
                return this.mName;
            else
                return null;

        }
        public int getMachineSerialNumber(int mNum)
        {
            if (mNum == this.mNumber)
                return this.serialNumber;
            else 
                return 0;
        }
        public string getMachineStatus(int mNum)
        {
            if (mNum == this.mNumber)
                return this.status;
            else
                return null;
        }
        public void changeMachineStatus(int mNum, string newStatus)
        {
            if (mNum == this.mNumber)
                this.status = newStatus;
           
  
        }
        public double getMachineCost(int mNum)
        {
            if (mNum == this.mNumber)

                return this.machineCost;
            else
                return 0;
           
        }
        public int getMachineNumber()
        {
            return this.mNumber;
        }

    }
}