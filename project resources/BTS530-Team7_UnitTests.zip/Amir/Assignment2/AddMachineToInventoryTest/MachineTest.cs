﻿using Assignment2.Classes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace AddMachineToInventoryTest
{
    
    [TestClass()]
    public class MachineTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
            
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
            
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        //  [HostType("ASP.NET")]
        //  [AspNetDevelopmentServerHost("C:\\Users\\Amir\\Documents\\Sem5\\BTS530\\Assignment2\\Assignment2", "/")]
        //  [UrlToTest("http://localhost:1516/")]

        //**********Test 1**********//

        [TestMethod()]
        public void checkStatusOfAMachineWhenItIsNewlyAddedToInventory()
        {
            //variable to instantiate Machine class
            int Num = 1; 
            string Name = "Civic"; 
            double CSFeet = 22.33; 
            int serialNum = 12345; 
            string status = "Available";
            double cost = 2222.54;

            //variables to instantiate MachineBrand class
            int brandID = 22;
            int mBrandNum = 333;
            
            //Variable to instantiate User class
            int userID = 1;
            int userPhoneNumber = 416555555;
            string password = "abcd";

            MachineBrand m = new MachineBrand(brandID, "Honda", mBrandNum); 
            User u = new User(userID, "Amir", "Bijarchi", userPhoneNumber, "1102-100 Pond Dr", "a@hotmail.com", password, "Active");
            Machine target = new Machine(Num, Name, CSFeet, serialNum, status, m, u, cost); 


            string expected = "Available"; 
            string actual;
            actual = target.getMachineStatus(Num);
            Assert.AreEqual(expected, actual);

        }

        //**********Test 2**********//

        [TestMethod()]
        public void checkAgentNameThatMachineIsAssignedTo()
        {
            //variable to instantiate Machine class
            int Num = 1;
            string Name = "Civic";
            double CSFeet = 22.33;
            int serialNum = 12345;
            string status = "Available";
            double cost = 2222.54;

            //variables to instantiate MachineBrand class
            int brandID = 22;
            int mBrandNum = 333;

            //Variable to instantiate User class
            int userID = 1;
            int userPhoneNumber = 416555555;
            string password = "abcd";

            MachineBrand m = new MachineBrand(brandID, "Honda", mBrandNum);
            User u = new User(userID, "Amir", "Bijarchi", userPhoneNumber, "1102-100 Pond Dr", "a@hotmail.com", password, "Active");
            Machine target = new Machine(Num, Name, CSFeet, serialNum, status, m, u, cost); 

            string expected = "Amir, Bijarchi";
            string actual;
            actual = u.getUserName();
            Assert.AreEqual(expected, actual);

        }

        //**********Test 3**********//

        [TestMethod()]
        public void CheckBrandOftheMachineThatItIsaddedToInventory()
        {
            //variable to instantiate Machine class
            int Num = 1;
            string Name = "Civic";
            double CSFeet = 22.33;
            int serialNum = 12345;
            string status = "Available";
            double cost = 2222.54;

            //variables to instantiate MachineBrand class
            int brandID = 22;
            int mBrandNum = 333;

            //Variable to instantiate User class
            int userID = 1;
            int userPhoneNumber = 416555555;
            string password = "abcd";

            MachineBrand m = new MachineBrand(brandID, "Honda", mBrandNum);
            User u = new User(userID, "Amir", "Bijarchi", userPhoneNumber, "1102-100 Pond Dr", "a@hotmail.com", password, "Active");
            Machine target = new Machine(Num, Name, CSFeet, serialNum, status, m, u, cost); 

            string expected = "Honda"; 
            string actual;
            actual = m.getMachineBrandName(brandID);
            Assert.AreEqual(expected, actual);

        }


        //**********Test 4**********//

        [TestMethod()]
        public void changeStatusOfaMachineAfterMachineIsRented()
        {
            //variable to instantiate Machine class
            int Num = 1;
            string Name = "Civic";
            double CSFeet = 22.33;
            int serialNum = 12345;
            string status = "Available";
            double cost = 2222.54;

            //variables to instantiate MachineBrand class
            int brandID = 22;
            int mBrandNum = 333;

            //Variable to instantiate User class
            int userID = 1;
            int userPhoneNumber = 416555555;
            string password = "abcd";

            MachineBrand m = new MachineBrand(brandID, "Honda", mBrandNum);
            User u = new User(userID, "Amir", "Bijarchi", userPhoneNumber, "1102-100 Pond Dr", "a@hotmail.com", password, "Active");
            Machine target = new Machine(Num, Name, CSFeet, serialNum, status, m, u, cost); 

            target.changeMachineStatus(Num,"In Use");

            string expected = "In Use"; 
            string actual;
            actual = target.getMachineStatus(Num);
            Assert.AreEqual(expected, actual);
           
        }

        //**********Test 5**********//

        //[TestMethod()]
        //public void CheckTheMachineNameWithPassingTheMachineID()
        //{
        //    //variable to instantiate Machine class
        //    int Num = 1;
        //    string Name = "Civic";
        //    double CSFeet = 22.33;
        //    int serialNum = 12345;
        //    string status = "Available";
        //    double cost = 2222.54;

        //    //variables to instantiate MachineBrand class
        //    int brandID = 22;
        //    int mBrandNum = 333;

        //    //Variable to instantiate User class
        //    int userID = 1;
        //    int userPhoneNumber = 416555555;
        //    string password = "abcd";

        //    MachineBrand m = new MachineBrand(brandID, "Honda", mBrandNum);
        //    User u = new User(userID, "Amir", "Bijarchi", userPhoneNumber, "1102-100 Pond Dr", "a@hotmail.com", password, "Active");
        //    Machine target = new Machine(Num, Name, CSFeet, serialNum, status, m, u, cost);

        //    string expected = "Civic";
        //    string actual;
        //    actual = target.getMachineName(Num);
        //    Assert.AreEqual(expected, actual);

        //}

    }
}
