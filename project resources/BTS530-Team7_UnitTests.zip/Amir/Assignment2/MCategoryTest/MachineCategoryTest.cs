﻿using Assignment2.Classes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace MCategoryTest
{
    
    
    /// <summary>
    ///This is a test class for MachineCategoryTest and is intended
    ///to contain all MachineCategoryTest Unit Tests
    ///</summary>
    [TestClass()]
    public class MachineCategoryTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for getModel
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\Amir\\Documents\\Sem5\\BTS530\\Assignment2\\Assignment2", "/")]
        [UrlToTest("http://localhost:1516/")]
        public void getModelTest()
        {
            int cID = 1; // TODO: Initialize to an appropriate value
            string bName = "Honda"; // TODO: Initialize to an appropriate value
            int mNumber = 11; // TODO: Initialize to an appropriate value
            Machine d = null; // TODO: Initialize to an appropriate value
            MachineCategory target = new MachineCategory(cID, bName, mNumber, d); // TODO: Initialize to an appropriate value
            int expected = 11; // TODO: Initialize to an appropriate value
            int actual;
            actual = target.getModel();
            Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for getbrandName
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\Amir\\Documents\\Sem5\\BTS530\\Assignment2\\Assignment2", "/")]
        [UrlToTest("http://localhost:1516/")]
        public void getbrandNameTest()
        {
            int cID = 2; // TODO: Initialize to an appropriate value
            string bName = "Toyota"; // TODO: Initialize to an appropriate value
            int mNumber = 22; // TODO: Initialize to an appropriate value
            Machine d = null; // TODO: Initialize to an appropriate value
            MachineCategory target = new MachineCategory(cID, bName, mNumber, d); // TODO: Initialize to an appropriate value
            string expected = "Toyota"; // TODO: Initialize to an appropriate value
            string actual;
            actual = target.getbrandName();
            Assert.AreEqual(expected, actual);
           // Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for getmCatID
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\Amir\\Documents\\Sem5\\BTS530\\Assignment2\\Assignment2", "/")]
        [UrlToTest("http://localhost:1516/")]
        public void getmCatIDTest()
        {
            int cID = 3; // TODO: Initialize to an appropriate value
            string bName = "Acura"; // TODO: Initialize to an appropriate value
            int mNumber = 33; // TODO: Initialize to an appropriate value
            Machine d = null; // TODO: Initialize to an appropriate value
            MachineCategory target = new MachineCategory(cID, bName, mNumber, d); // TODO: Initialize to an appropriate value
            int expected = 3; // TODO: Initialize to an appropriate value
            int actual;
            actual = target.getmCatID();
            Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }
        /// <summary>
        ///A test for getmCatID
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\Amir\\Documents\\Sem5\\BTS530\\Assignment2\\Assignment2", "/")]
        [UrlToTest("http://localhost:1516/")]
        public void getMachineNmae()
        {
            int cID = 4; // TODO: Initialize to an appropriate value
            string bName = "BMW"; // TODO: Initialize to an appropriate value
            int mNumber = 344; // TODO: Initialize to an appropriate value
            Machine d = new Machine(11, "x5", 22.99, 1234, "x5"); // TODO: Initialize to an appropriate value
            MachineCategory target = new MachineCategory(cID, bName, mNumber, d); // TODO: Initialize to an appropriate value
            string expected = "x5" ; // TODO: Initialize to an appropriate value
            string actual;
            actual = d.getStatus();
            Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}
