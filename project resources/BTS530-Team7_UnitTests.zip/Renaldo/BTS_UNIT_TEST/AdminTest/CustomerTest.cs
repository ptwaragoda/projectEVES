﻿using BTS_UNIT_TEST;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace AdminTest
{
    [TestClass()]
    public class CustomerTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        public void CreateANewAuthorizedUser()
        {
            //User yourDaddy = new User();
            User newAthorized = new User(new User(), "Claire", "Manager");
            User expected = newAthorized;
            string actual = newAthorized.userDetails();
            Assert.AreEqual("Claire", actual);
        }
        [TestMethod()]
        public void CreateANewCustomer()
        {
            //User yourDaddy = new User();
            User existingAgent = new User(new User(), "Andrea", "Agent");
            Customer newCustomer = new Customer(existingAgent, "Tanya");
            User expected = existingAgent;
            User actual = newCustomer.setMyParent(expected);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void ReassignACustomerToANewAgent()
        {
            User agent = new User(new User(), "Natasha", "Agent");
            Customer customer = new Customer(agent, "Vincent"); 
            //Natasha Left
            User newAgent = new User(new User(), "Jessica", "Agent");
            customer.setMyParent(newAgent);
            Assert.AreEqual(newAgent, customer.getMyParent());
        }
        [TestMethod()]
        public void ReassignAnAgentToANewManager()
        {
            User manager = new User(new User(), "Alfred", "Manager");
            User agent = new User(manager, "Michael", "Agent");
            //Alfred is left, for w/e reason
            User newManager = new User(new User(), "Jessica", "Manager");
            agent.setMyParent(newManager);
            Assert.AreEqual(newManager, agent.getMyParent());
        }
         /** */
    }
}
