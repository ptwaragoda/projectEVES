﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BTS_UNIT_TEST
{
    public class User
    {
        string  _userName;
        string  _userType;
        User    _parent;

       public User(User parent, string name, string userType){
           this._parent = parent;
           this._userName = name;
           this._userType = userType;
       }
       public User()
       {
           this._parent = null;
           _userName    = "Admin";
       }
        public string userDetails() { return _userName; }
        public User setMyParent(User parent) { this._parent = parent; return _parent; }
        public User getMyParent(){ return this._parent; }
    }

    public class Customer
    {
        User    _parent;
        string  _customerName;
        
        public Customer( User parentObj,string name)
        {
            this._parent        = parentObj;
            this._customerName  = name;
        }

        public User setMyParent(User parent) { this._parent = parent; return _parent; }
        public string customerDetails(){ return _customerName;}
        public User getMyParent(){ return this._parent; }
    }
}