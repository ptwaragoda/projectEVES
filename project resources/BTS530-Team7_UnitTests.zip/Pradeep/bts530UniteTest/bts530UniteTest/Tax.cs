﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bts530UniteTest
{
    public class Tax
    {
        int taxID;
        String taxProvince, taxDesc;
        float taxVal;

        public Tax(int taxID, String taxProvince, String taxDesc, float taxVal)
        {
            this.taxID = taxID;
            this.taxProvince = taxProvince;
            this.taxVal = taxVal;
            this.taxDesc = taxDesc;
        }

        public float getTaxVal()
        {
            return taxVal;
        }

    }
}
