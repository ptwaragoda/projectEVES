﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bts530UniteTest
{
    public class MachineBrand
    {
        int brandID;
        string brandName;
        int brandSerialNumber;
        private int cID;
        private string bName;
        private int mNumber;
        private Machine d;


        public MachineBrand(int bID, string bName, int mBrandNumber)
        {
            this.brandID = bID;
            this.brandName = bName;
            this.brandSerialNumber = mBrandNumber;


        }

        public MachineBrand(int cID, string bName, int mNumber, Machine d)
        {
            // TODO: Complete member initialization
            this.cID = cID;
            this.bName = bName;
            this.mNumber = mNumber;
            this.d = d;
        }
        public int getMachineBrandID()
        {
            return this.brandID;
        }
        public int getMachineSerialNumber(int bID)
        {
            if (bID == this.brandID)
                return this.brandSerialNumber;
            else
                return 0;
        }
        public string getMachineBrandName(int bID)
        {
            if (bID == this.brandID)
                return this.brandName;
            else
                return null;
        }
    }
}