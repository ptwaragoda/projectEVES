﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bts530UniteTest
{
    public class Machine
    {
        int mNumber;
        string mName;
        double coverSquireFeet;
        int serialNumber;
        string status;
        MachineBrand machineBrand;
        User user;
        float price;

        public Machine()
        {

        }

        public Machine(int Num, string Name, double CSFeet, int serialNum, string s, MachineBrand m, User u, float price)
        {
            this.mNumber = Num;
            this.mName = Name;
            this.coverSquireFeet = CSFeet;
            this.serialNumber = serialNum;
            this.status = s;
            this.machineBrand = m;
            this.user = u;
            this.price = price;

        }
        public string getMachineName(int mnum)
        {
            if (mnum == this.mNumber)
                return this.mName;
            else
                return null;

        }
        public int getMachineSerialNumber(int mNum)
        {
            if (mNum == this.mNumber)
                return this.serialNumber;
            else 
                return 0;
        }
        public string getMachineStatus(int mNum)
        {
            if (mNum == this.mNumber)
                return this.status;
            else
                return null;
        }
        public void changeMachineStatus(int mNum, string newStatus)
        {
            if (mNum == this.mNumber)
                this.status = newStatus;
           
  
        }
        public int getMachineNumber()
        {
            return this.mNumber;
        }


        public float getPrice()
        {
            return price;
        }
        public void setPrice(float p)
        {
            price = p;
        }

        public string getStatus()
        {
            return status;
        }

    }
}