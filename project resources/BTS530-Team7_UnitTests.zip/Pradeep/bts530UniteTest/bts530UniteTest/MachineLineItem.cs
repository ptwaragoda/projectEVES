﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

namespace bts530UniteTest
{
    public class MachineLineItem
    {
        int machineLineId, transID, quantity;
        //int mNumber;
        ArrayList mc;

        public MachineLineItem(int machineLineId, int transID, int quantity)
        {
            this.machineLineId = machineLineId;
            this.transID = transID;
            //this.mNumber = mNumber;
            this.quantity = quantity;
            mc = new ArrayList();
        }

        //public int getMnumber()
        //{return mNumber;}
        //public void setMnumber(int mnumber)
        //{
        //    mNumber = mnumber;
        //}

        public int getMachineLineId()
        {
            return machineLineId;
        }
        public void setMachineLineId(int mlid)
        {
            machineLineId = mlid;
        }

        public int getTransId()
        {
            return transID;
        }
        public void setTransId(int tId)
        {
            transID = tId;
        }


        public int getQuantity()
        {
            return quantity;
        }
        public void setQuantity(int qty)
        {
            quantity = qty;
        }

        public void addMachines(Machine m)
        {
            mc.Add(m);
        }

        public ArrayList getMachineArray()
        {
            return mc;
        }
    }
}