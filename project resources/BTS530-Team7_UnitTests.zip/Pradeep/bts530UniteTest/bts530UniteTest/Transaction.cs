﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using bts530UniteTest;

namespace bts530UniteTest
{
    public class Transaction
    {
        int transID;
        float totalRent, tax, finalTotal;
        String agentName;
        Customer cs;
        DateTime startDate, endDate, transDate;
       // ArrayList machines = new ArrayList();
        MachineLineItem mli;

        public Transaction(int transID, float tax, String agent, Customer c, DateTime sd, DateTime ed, DateTime td)
        {
            this.transID = transID;
            this.totalRent = 0;
            this.finalTotal = 0;
            this.agentName = agent;
            this.cs = c;
            this.startDate = sd;
            this.endDate = ed;
            this.transDate = td;
            mli=new MachineLineItem(transID+11, transID,0);

        }

        public int getTransId()
        {
            return transID;
        }

        public void setMachines(Machine m)
        {
            mli.addMachines(m);
        }

        public ArrayList getMachineList()
        {
            ArrayList temp = mli.getMachineArray();
            return temp;
        }
        public float getTotal()
        {
            ArrayList temp = mli.getMachineArray();
            Machine t = new Machine();
            if (temp[0] != null)
            {
                foreach (Machine n in temp)
                {
                    t =(Machine) n;
                    totalRent += t.getPrice();
                }
            }
            
            return totalRent;
        }

        public string getCustomerName()
        {
            return cs.getCustFName();
        }
    }
}