﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bts530UniteTest
{
    public class Customer
    {
        String cfName, clName, companyName,companyAddress, cEmail, agent;
        String cPhone;
        int custID;

       public Customer(int custID, String cfName, String clName, String companyName, String companyAddress, String cEmail, String agent, String cPhone)
        {
            this.custID = custID;
            this.cfName = cfName;
            this.clName = clName;
            this.companyAddress = companyAddress;
            this.companyName = companyName;
            this.cEmail = cEmail;
            this.agent = agent; // this might change eventually
            this.cPhone = cPhone;
        }

        public string getCustFName()
        {
            return cfName;
        }
        public void setCustFName(String cfname)
        {
             cfName=cfname;
        }


        public string getCustLName()
        {
            return clName;
        }
        public void setCustLName(String clname)
        {
             clName=clname;
        }



        public string getCompAdress()
        {
            return companyAddress;
        }
        public void setCompAdress(String caddress)
        {
             companyAddress=caddress;
        }


        public string getCompName()
        {
            return companyName;
        }
        public void setCompName(String compname)
        {
             companyName=compname;
        }


        public string getCustEmail()
        {
            return cEmail;
        }
        public void setCustEmail(String cemail)
        {
             cEmail=cemail;
        }


        public String getCustPhone()
        {
            return cPhone;
        }
        public void setCustPhone(String cphone)
        {
            cPhone=cphone;
        }


        public string getAgent()
        {
            return agent;
        }
        public void setAgent(String ag)
        {
            agent=ag;
        }
    }
}