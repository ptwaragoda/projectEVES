﻿using bts530UniteTest;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace TransectionUniteTest
{
    
    
    /// <summary>
    ///This is a test class for TransactionCustomer and is intended
    ///to contain all TransactionCustomer Unit Tests
    ///</summary>
    [TestClass()]
    public class TransactionCustomer
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            Tax tt = new Tax(11,"Ontario","Ontario HST tax",0.13F);
            //Customer c = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", "peter", "416-444-3333");
            User u = new User(3232, "peter", "gibson", 1101, "23 cappella dr", "peter@peter.com", "23werule", "Active");
            Customer cu = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", u.getUserName(), "416-444-3333");

        }
        
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            Tax tt = new Tax(11, "Ontario", "Ontario HST tax", 0.13F);
            //Customer c = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", "peter", "416-444-3333");
            User u = new User(3232, "peter", "gibson", 1101, "23 cappella dr", "peter@peter.com", "23werule", "Active");
            Customer cu = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", u.getUserName(), "416-444-3333");

        }
        
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Transaction Constructor
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
    //    [HostType("ASP.NET")]
      //  [AspNetDevelopmentServerHost("C:\\Documents and Settings\\Administrator\\My Documents\\Dropbox\\bts530\\bts530UniteTest\\bts530UniteTest", "/")]
        //[UrlToTest("http://localhost:3161/")]

        //************************** Test 1 Checking the constructor by passing currect classes and values to initialize
        public void TransactionConstructorWithAllTheClassesTest()
        {
            Tax tt = new Tax(11, "Ontario", "Ontario HST tax", 0.13F);
            //Customer c = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", "peter", "416-444-3333");
            User u = new User(3232, "peter", "gibson", 1101, "23 cappella dr", "peter@peter.com", "23werule", "Active");
            Customer cu = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", u.getUserName(), "416-444-3333");

            int transID = 12344321; // TODO: Initialize to an appropriate value
            float tax = tt.getTaxVal(); // TODO: Initialize to an appropriate value
            string agent = u.getUserName(); // TODO: Initialize to an appropriate value
            Customer c =  cu; // TODO: Initialize to an appropriate value
            DateTime sd = new DateTime(2011,12,8); // TODO: Initialize to an appropriate value
            DateTime ed = new DateTime(2012, 1, 8); // TODO: Initialize to an appropriate value
            DateTime td = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            Transaction target = new Transaction(transID, tax, agent, c, sd, ed, td);
            //Assert.Inconclusive("TODO: Implement code to verify target");
            Assert.AreEqual(target.getCustomerName(), "Mark");
        }

        [TestMethod()]
        //************************** Test 2 Add a machine to the Transaction 
        public void addAMachineToTheTransactionTest()
        {
           
            User u = new User(3232, "peter", "gibson", 1101, "23 cappella dr", "peter@peter.com", "23werule", "Active");
            Customer cu = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", u.getUserName(), "416-444-3333");
            MachineBrand mbran = new MachineBrand(2020,"Honda",20023);
            Tax tt = new Tax(11, "Ontario", "Ontario HST tax", 0.13F);
            Machine m = new Machine(1001,"BellClean 100",12.2F,221104,"Available",mbran, u,100.0F);
            int transID = 12344321; // TODO: Initialize to an appropriate value
            float tax = tt.getTaxVal(); // TODO: Initialize to an appropriate value
            string agent = u.getUserName(); // TODO: Initialize to an appropriate value
            Customer c = cu; // TODO: Initialize to an appropriate value
            DateTime sd = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            DateTime ed = new DateTime(2012, 1, 8); // TODO: Initialize to an appropriate value
            DateTime td = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            Transaction target = new Transaction(transID, tax, agent, c, sd, ed, td);
            target.setMachines(m);
            Assert.AreEqual(target.getMachineList().Count, 1);

        }

        [TestMethod()]
        //**************************test 3 adding two items to the same transaction
        public void addTwoMachinesToTheTransactionTest()
        {
            User u = new User(3232, "peter", "gibson", 1101, "23 cappella dr", "peter@peter.com", "23werule", "Active");
            Customer cu = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", u.getUserName(), "416-444-3333");
            MachineBrand mbran = new MachineBrand(2020, "Honda", 20023);
            Tax tt = new Tax(11, "Ontario", "Ontario HST tax", 0.13F);
            Machine m = new Machine(1001, "BellClean 100", 12.2F, 221104, "Available", mbran, u, 100.0F);
            Machine m2 = new Machine(1014, "Galaxy", 10.5F, 432404, "Available", mbran, u, 130.0F);
            int transID = 12344321; // TODO: Initialize to an appropriate value
            float tax = tt.getTaxVal(); // TODO: Initialize to an appropriate value
            string agent = u.getUserName(); // TODO: Initialize to an appropriate value
            Customer c = cu; // TODO: Initialize to an appropriate value
            DateTime sd = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            DateTime ed = new DateTime(2012, 1, 8); // TODO: Initialize to an appropriate value
            DateTime td = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            Transaction target = new Transaction(transID, tax, agent, c, sd, ed, td);
            target.setMachines(m);
            target.setMachines(m2);
            Assert.AreEqual(target.getMachineList().Count, 2);

        }

       

        [TestMethod()]
        //************************** Test4 adding one machine to the transaction and get the price
        public void addOneMachineAndGetPriceFromTransactionTest()
        {
            User u = new User(3232, "peter", "gibson", 1101, "23 cappella dr", "peter@peter.com", "23werule", "Active");
            Customer cu = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", u.getUserName(), "416-444-3333");
            MachineBrand mbran = new MachineBrand(2020, "Honda", 20023);
            Tax tt = new Tax(11, "Ontario", "Ontario HST tax", 0.13F);
            Machine m = new Machine(1001, "BellClean 100", 12.2F, 221104, "Available", mbran, u, 100.0F);
            
            int transID = 12344321; // TODO: Initialize to an appropriate value
            float tax = tt.getTaxVal(); // TODO: Initialize to an appropriate value
            string agent = u.getUserName(); // TODO: Initialize to an appropriate value
            Customer c = cu; // TODO: Initialize to an appropriate value
            DateTime sd = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            DateTime ed = new DateTime(2012, 1, 8); // TODO: Initialize to an appropriate value
            DateTime td = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            Transaction target = new Transaction(transID, tax, agent, c, sd, ed, td);
            target.setMachines(m);
         
            Assert.AreEqual(target.getTotal(), 100F);

        }

        [TestMethod()]
        //************************** Test5 adding two items to the same transaction and get the price
        public void addTwoMachinesAndGetPriceFromTransactionTest()
        {
            User u = new User(3232, "peter", "gibson", 1101, "23 cappella dr", "peter@peter.com", "23werule", "Active");
            Customer cu = new Customer(111, "Mark", "Peder", "Manulife", "1 bay st", "mark.pender@manulife.com", u.getUserName(), "416-444-3333");
            MachineBrand mbran = new MachineBrand(2020, "Honda", 20023);
            Tax tt = new Tax(11, "Ontario", "Ontario HST tax", 0.13F);
            Machine m = new Machine(1001, "BellClean 100", 12.2F, 221104, "Available", mbran, u, 100.0F);
            Machine m2 = new Machine(1014, "Galaxy", 10.5F, 432404, "Available", mbran, u, 130.0F);
            int transID = 12344321; // TODO: Initialize to an appropriate value
            float tax = tt.getTaxVal(); // TODO: Initialize to an appropriate value
            string agent = u.getUserName(); // TODO: Initialize to an appropriate value
            Customer c = cu; // TODO: Initialize to an appropriate value
            DateTime sd = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            DateTime ed = new DateTime(2012, 1, 8); // TODO: Initialize to an appropriate value
            DateTime td = new DateTime(2011, 12, 8); // TODO: Initialize to an appropriate value
            Transaction target = new Transaction(transID, tax, agent, c, sd, ed, td);
            target.setMachines(m);
            target.setMachines(m2);
            Assert.AreEqual(target.getTotal(), 230F);

        }

        
    }
}
