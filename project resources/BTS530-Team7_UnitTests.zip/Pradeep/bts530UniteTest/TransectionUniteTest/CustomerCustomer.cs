﻿using bts530UniteTest;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace TransectionUniteTest
{
    
    
    /// <summary>
    ///This is a test class for CustomerCustomer and is intended
    ///to contain all CustomerCustomer Unit Tests
    ///</summary>
    [TestClass()]
    public class CustomerCustomer
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Customer Constructor
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
       // [HostType("ASP.NET")]
       // [AspNetDevelopmentServerHost("C:\\Documents and Settings\\Administrator\\My Documents\\Dropbox\\bts530\\bts530UniteTest\\bts530UniteTest", "/")]
      //  [UrlToTest("http://localhost:3161/")]
        public void CustomerConstructorTest()
        {
            int cid = 12331;
            string cfName = "Mark"; // TODO: Initialize to an appropriate value
            string clName = "Pender"; // TODO: Initialize to an appropriate value
            string companyName = "Manulife"; // TODO: Initialize to an appropriate value
            string companyAddress = "1 Bay street"; // TODO: Initialize to an appropriate value
            string cEmail = "Mark.pender@manulife.com"; // TODO: Initialize to an appropriate value
            string agent = "Peter"; // TODO: Initialize to an appropriate value
            string cPhone = "416-444-3333"; // TODO: Initialize to an appropriate value
            Customer target = new Customer(cid,cfName, clName, companyName, companyAddress, cEmail, agent, cPhone);
            //Assert.Inconclusive("TODO: Implement code to verify target");
            Assert.AreEqual(target.getCustFName(), "Mark");
        }
    }
}
